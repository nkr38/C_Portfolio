#ifndef _ezinput_
#define _ezinput_

char ezinput();

#endif